import numpy as np
from zounds.analyze.bark import bark_bands
from time import time

samplerate = 44100
nbands = 100
windowsize = 2048
start_freq = 50
stop_freq = 12000


    

if __name__ == '__main__':
    
    def pythonloop(af):
        nframes = af.shape[0]
        cb = np.ndarray((nframes,nbands))
        for i in xrange(nframes):
            fft = np.abs(np.fft.rfft(af[i]))[1:]
            cb[i] = bark_bands(samplerate,windowsize,nbands,start_freq,stop_freq,fft,1)
        return cb

    def cloop(af):
        nframes = af.shape[0]
        fft = np.abs(np.fft.rfft(af))[:,1:]
        return bark_bands(samplerate,windowsize,nbands,start_freq,stop_freq,fft,nframes)
    
    
    # 200 frames, or ~5 seconds
    audio = np.random.random_sample((1000,windowsize))
    start = time()
    pl = pythonloop(audio)
    print 'python loop took %1.4f seconds' % (time() - start)
    
    start = time()
    cl = cloop(audio)
    print 'c loop took %1.4f seconds' % (time() - start)
    
    assert np.all(pl == cl)