'''
Random seek times
Read a few random ids
Read some random external_ids
'''
from uuid import uuid4
import numpy as np
from tables import *
import os
from time import time
import shutil

start = None

def tic():
    global start
    start = time()

def toc(msg):
    print '%s took %1.4f seconds' % (msg,time() - start)

hdf5name = 'table_test.h5'
dirname = uuid4().hex

def setup():
    os.makedirs(dirname)

def teardown():
    shutil.rmtree(dirname)

class DataDesc(IsDescription):
    _id = StringCol(itemsize = 32, pos = 0)
    frame = Int32Col(pos = 1)
    audio = Float32Col(shape = 2048,pos = 2)
    bark = Float32Col(shape = 100, pos = 3)
    conv = Float32Col(shape = 1500, pos = 4)
    packed = UInt64Col(pos = 5)

dtype = [('_id','a32'),
         ('frame',np.int32),
         ('audio',np.float32,2048),
         ('bark',np.float32,100),
         ('conv',np.float32,1500),
         ('packed',np.uint64)]


def record(nframes):
    r = np.recarray(nframes,dtype = dtype)
    r['_id'][:] = uuid4().hex
    return r


def population(n,shortest=10,longest=500):
    #return dict([(uuid4().hex,np.random.randint(shortest,longest)) for i in range(n)])
    pop = []
    offset = 0
    for i in xrange(n):
        _id = uuid4().hex
        l = np.random.randint(shortest,longest)
        pop.append((_id,offset,l))
        offset += l
    return pop
        
def queries(pop,n):
    indices = np.random.permutation(len(pop))[:n]
    q = []
    for i in indices:
        _id,offset,length = pop[i]
        qs = np.random.randint(length)
        ql = np.random.randint(length - qs)
        q.append((_id,offset,qs,ql))
    return q

def _ids(pop,n):
    indices = np.random.permutation(len(pop))[:n]
    return [pop[i][0] for i in indices]
    
def create_table(pop):
    db = openFile(hdf5name,'w')
    db.createTable('/','table',DataDesc)
    table = db.root.table
    table.autoIndex = False
    table.cols._id.createIndex()
    for _id,offset,length in pop:
        table.append(record(length))
        table.flush()
    table.reIndexDirty()
    db.close()

def read_table():
    db = openFile(hdf5name,'r')
    return db.root.table

def create_files(pop):
    # TODO: Could this be sped up using multiprocessing?  My guess is "no".
    # I think the bottleneck will be actually writing to disk.
    for _id,offset,length in pop:
        rec = record(length)
        rec.tofile('%s/%s.dat' % (dirname,_id))

def table_fetch(table,q):
    results = []
    for _id,offset,qs,ql in q:
        start = offset + qs
        stop = start + ql
        results.append(table[start : stop])
    return results

def table_fetch_ids(table,ids):
    results = []
    for _id in ids:
        results.append(table.readWhere('_id == "%s"' % _id))
    return results

def file_fetch(q):
    results = []
    for _id,offset,qs,ql in q:
        arr = np.memmap('%s/%s.dat' % (dirname,_id),dtype = dtype, mode = 'r')
        results.append(arr[qs : qs + ql])
        del arr
    return results

def file_fetch_ids(ids):
    results = []
    for _id in ids:
        results.append(np.fromfile('%s/%s.dat' % (dirname,_id),dtype = dtype))
    return results

if __name__ == '__main__':
    setup()
    try:
        pop = population(500)
        tic()
        create_table(pop)
        toc('tables')
        tic()
        create_files(pop)
        toc('files')
        q = queries(pop,50)
        tr = read_table()
        tic()
        tresults = table_fetch(tr,q)
        toc('tables seek')
        tic()
        fresults = file_fetch(q)
        toc('file seek')
        assert len(tresults) == len(fresults)
        for i in xrange(len(tresults)):
            assert len(tresults[i]) == len(fresults[i])
        ids = _ids(pop,10)
        tic()
        tresults = table_fetch_ids(tr,ids)
        toc('tables fetch ids')
        tic()
        fresults = file_fetch_ids(ids)
        toc('file fetch ids')
        assert len(tresults) == len(fresults)
        for i in xrange(len(tresults)):
            assert len(tresults[i]) == len(fresults[i])
    finally:
        teardown()