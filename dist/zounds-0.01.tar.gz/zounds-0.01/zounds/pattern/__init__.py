import pyximport
pyximport.install()
from play import * 