import unittest
from uuid import uuid4
import os
import numpy as np


from zounds.analyze.feature.spectral import FFT,Loudness
from zounds.data.frame import PyTablesFrameController,FileSystemFrameController
from zounds.model.frame import Feature,Frames
from zounds.model.pattern import FilePattern
from zounds.environment import Environment
from zounds.testhelper import make_sndfile,remove

from fetch import PrecomputedFeature

class PrecomputedFeatureTests(object):
    
    
    def set_up(self):
        self.to_cleanup = []
        Environment._test = True
    
    def tear_down(self):
        for c in self.to_cleanup:
            remove(c)
        Environment._test = False
    
    def tearDown(self):
        for tc in self.to_cleanup:
            remove(tc)
        Environment._test = False
    
    class FrameModel(Frames):
        fft = Feature(FFT, store = True, needs = None)
        loudness = Feature(Loudness, store = True, needs = fft)
    
    class AudioConfig:
        samplerate = 44100
        windowsize = 2048
        stepsize = 1024
        window = None
    
    def append_files(self,
                     framecontroller,
                     framecontroller_args,
                     framemodel = FrameModel,
                     file_lengths = [44100, 44100 * 1.3]):
        
        env = Environment('test',
                          framemodel,
                          framecontroller,
                          tuple([framemodel] + list(framecontroller_args)),
                          {},
                          audio = PrecomputedFeatureTests.AudioConfig)
        
        msf = make_sndfile
        filenames = [msf(fl,env.windowsize,env.samplerate)\
                      for fl in file_lengths]
        self.to_cleanup.extend(filenames)
        for i,fn in enumerate(filenames):
            _id = str(i)
            fp = FilePattern(_id,'test',_id,fn)
            ec = framemodel.extractor_chain(fp)
            framemodel.controller().append(ec)
        
        return env,framemodel,filenames
    
    @property
    def framecontroller(self):
        raise NotImplemented()
    
    @property
    def framecontroller_args(self):
        raise NotImplemented()

    def test_data_proper_shape_oned(self):
        env,framemodel,filenames = self.append_files(\
                            self.framecontroller, self.framecontroller_args)
        pc = PrecomputedFeature(1,
                                PrecomputedFeatureTests.FrameModel.loudness)
        data = pc(nexamples = 10)
        self.assertEqual((10,),data.shape)
    
    def test_data_proper_shape_oned_nframes_2(self):
        env,framemodel,filenames = self.append_files(\
                            self.framecontroller, self.framecontroller_args)
        pc = PrecomputedFeature(2,
                                PrecomputedFeatureTests.FrameModel.loudness)
        data = pc(nexamples = 10)
        self.assertEqual((10,2),data.shape)
            
    def test_data_proper_shape_twod(self):              
        env,framemodel,filenames = self.append_files(\
                            self.framecontroller, self.framecontroller_args)
        pc = PrecomputedFeature(1,
                                PrecomputedFeatureTests.FrameModel.fft)
        data = pc(nexamples = 11)
        expected_axis1 = PrecomputedFeatureTests.AudioConfig.windowsize / 2
        self.assertEqual((11,expected_axis1),data.shape)
    
    def test_data_proper_shape_twod_nframes_2(self):
        env,framemodel,filenames = self.append_files(\
                            self.framecontroller, self.framecontroller_args)
        pc = PrecomputedFeature(2,
                                PrecomputedFeatureTests.FrameModel.fft)
        data = pc(nexamples = 11)
        expected_axis1 = PrecomputedFeatureTests.AudioConfig.windowsize / 2
        self.assertEqual((11,expected_axis1*2),data.shape)
            
    def test_pattern_shorter_than_nframes(self):
        env,framemodel,filenames = self.append_files(\
            self.framecontroller, 
            self.framecontroller_args,
            file_lengths = [2048,44100])
        pc = PrecomputedFeature(3,
                                PrecomputedFeatureTests.FrameModel.fft)
        data = pc(nexamples = 20)
        expected_axis1 = PrecomputedFeatureTests.AudioConfig.windowsize / 2
        self.assertEqual((20,expected_axis1*3), data.shape)
    
    def test_pattern_too_many_frames(self):
        env,framemodel,filenames = self.append_files(\
            self.framecontroller,
             self.framecontroller_args,
             file_lengths = [2048,44100])
        pc = PrecomputedFeature(3,
                              PrecomputedFeatureTests.FrameModel.fft)
        self.assertRaises(ValueError,lambda : pc(nexamples = 2000000))
            
    def test_with_reduction(self):
        env,framemodel,filenames = \
              self.append_files(self.framecontroller, self.framecontroller_args)
        pc = PrecomputedFeature(\
                    3,PrecomputedFeatureTests.FrameModel.fft,reduction = np.max)
        samples = pc(10)
        self.assertEqual((10,1024),samples.shape)
    


class PyTablesPrecomputedFeatureTests(unittest.TestCase,PrecomputedFeatureTests):
    
    def setUp(self):
        PrecomputedFeatureTests.set_up(self)
        self.pytables_fn = '%s.h5' % uuid4().hex
        self.to_cleanup.append(self.pytables_fn)
    
    def tearDown(self):
        PrecomputedFeatureTests.tear_down(self)
    
    @property
    def framecontroller(self):
        return PyTablesFrameController

    @property
    def framecontroller_args(self):
        return (self.pytables_fn,)

class FileSystemPrecomputedFeatureTests(unittest.TestCase,PrecomputedFeatureTests):
    
    def setUp(self):
        PrecomputedFeatureTests.set_up(self)
        self.filesystem_dir = uuid4().hex
        self.to_cleanup.append(self.filesystem_dir)
    
    def tearDown(self):
        PrecomputedFeatureTests.tear_down(self)
    
    @property
    def framecontroller(self):
        return FileSystemFrameController
    
    @property
    def framecontroller_args(self):
        return (self.filesystem_dir,)
        
    