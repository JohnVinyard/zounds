'''
This module deals with data persistence
'''